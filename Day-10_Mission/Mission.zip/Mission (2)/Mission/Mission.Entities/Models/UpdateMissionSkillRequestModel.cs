﻿namespace Mission.Entities.Models
{
    public class UpdateMissionSkillRequestModel : AddMissionSkillRequestModel
    {
        public int Id { get; set; }
    }
}
